class News{
  late String newsHeader;
 // late  String newsDes;
  late String newsImg;
 // late String newsurl;
  News({required this.newsHeader ,required this.newsImg,});

static News fromJSON(dynamic map){
  return News(
    newsHeader: map['title'],
  // newsDes: map['description'],
   newsImg: map['urlToImage']??"https://cdn.pixabay.com/photo/2015/02/15/09/33/news-636978_640.jpg",
  //newsurl: map['url']
   );
}
}
