




import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';


class Itemss extends StatelessWidget {
 late String url;
 late String title;
  //late String description;
  Itemss({required this.url,required this.title,});
  

  @override
  Widget build(BuildContext context) {
    return  Expanded(child: 
    Column(
       children: [
        Container(
          height: 300,
          child: Image.network(url),
        ),
        Text(title,style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold
        ),)
       ],
    )
    );
    
   
     
       /*Scaffold(
            body:
                
                
               
                Container(
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(15, 5, 5, 5),
                        child: Row(mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(title,style: TextStyle(color: Colors.green,fontSize: 30,fontWeight:FontWeight.bold )),
                          ],
                        ),
                      ),
                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                      
                        shrinkWrap: true,
                        itemCount: 3,
                        itemBuilder: (context,index){
                         return Container(
                          
                        margin: EdgeInsets.symmetric(horizontal: 8,vertical: 3),
                          child: Card(
                            elevation: 10,
                            shadowColor: Colors.black,
                            shape:RoundedRectangleBorder (borderRadius:BorderRadius.circular(15)),
                            child: Stack(
                            children:[
                              
                            ClipRRect(
                              
                              borderRadius: BorderRadius.circular(15),
                              
                              child: Image.network(url),
                            ),
                          Positioned(
                            left: 0,right: 0,bottom: 0,
                            child: Container(
                              
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: LinearGradient(colors:[
                                  Colors.blueGrey.withOpacity(0),
                                  Colors.blueAccent,
                                  
        
                                ])
                              ),
                              padding: EdgeInsets.symmetric(horizontal: 10,vertical:5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(title,style: TextStyle(color:Colors.green,fontSize: 18,fontWeight: FontWeight.bold),
                                  ),
                                  Text(title,style: TextStyle(color: Colors.amber,fontSize: 12,fontWeight: FontWeight.bold),)
                                ],
                              )))
                          ]))
                         );
                      },
                      ),
                      
                    ],
                  )));*/
           
     
      
      
      
    

  
  }
}
  