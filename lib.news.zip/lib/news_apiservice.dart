import 'package:dio/dio.dart';
import 'package:news2/apiclient.dart';
import 'package:news2/news.dart';

class NewsService{
  ApiClient apiClient = ApiClient();
 Future<List<News>>  getNews() async{
    Response response = await apiClient.get('https://newsapi.org/v2/everything?q=query&from=2023-03-12&sortBy=publishedAt&apiKey=943dfec1b10141f6b3b0d18ef0d6815d');
    print(response.data);
    List<dynamic> list = response.data['articles'];
    List<News> Newss = list.map((m) => News.fromJSON(m)).toList();
    print(Newss);
    return Newss;
  }
}