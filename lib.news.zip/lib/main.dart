import 'package:flutter/material.dart';
import 'package:news2/screen/home.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
     home: Home(),
  ));
}
