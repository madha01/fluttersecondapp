


import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:news2/item.dart';
import 'package:news2/news.dart';
import 'package:news2/news_apiservice.dart';




class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  NewsService service = NewsService();

  // Bring the Data from the Service
  List<News> Newss = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future<List<News>> future = service.getNews();
    future.then((List<News> Newss) {
      this.Newss = Newss;
      setState(() {
        // setState will call build,
        // build will print the things
      });
    }).catchError((err) => print("Error is $err"));
    //  future.then().catchError();
  }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
          length: 4,
      child: Scaffold(
       appBar: AppBar(
         bottom: const TabBar(
                    isScrollable: true,
                    indicatorWeight: 1,
                    tabs: [
                    Tab(text: 'For You'),
                    Tab(text: 'Latest News'),
                    Tab(text: 'Local News'),
                    Tab(text: 'Cricket News'),
                  ],
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(50)),
                    color: Colors.blueGrey
                  ),),
        title: Text('News'),
       actions: [Icon(Icons.live_tv),Padding(padding: EdgeInsets.all(10))]
      ),
      body: 
       SingleChildScrollView(
        child: Column(children: [
          Container(
            padding: EdgeInsets.all(2),
            margin: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
            decoration: BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.circular(25)
            ),
            child: Row(children: [GestureDetector(
              onTap: (){},
              child: Container(child: Icon(Icons.search),
              padding: EdgeInsets.all(8),),
            ),
            Expanded(child: TextField(
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'news'
              ),
            ))
            ],),
          ),
      CarouselSlider(
                  options: CarouselOptions(
                    height: 200,
                    enlargeCenterPage: true,
                    autoPlay: true,
        
                  ),
                   items: items.map((item){
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15)
                              ),
                              child: Stack(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Image.network('https://cdn.pixabay.com/photo/2015/02/15/09/33/news-636978_640.jpg',fit: BoxFit.cover,height: double.infinity,),
                                    
                                  ),
                                  Positioned(
                                    left: 0,right: 0,bottom: 0,
                                    child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15),
                                      gradient: LinearGradient(colors: [
                                       Colors.black.withOpacity(0),
                                       Colors.black12 
                                      ],
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter
                                      )
                                    ),
                                    
                                    child: Container(
                                      padding: EdgeInsets.symmetric(horizontal: 7,vertical: 2),
                                      child: Text('madhav',style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),))),
                                  
                                  )
                              ],
                              ),
                            ),
                            
                        );
                      },
                    );
                   }
                   
                   ).toList(),
                ),
      
      
      
      
      
      
      Wrap(
        children: Newss.map((e) => Itemss(url: e.newsImg, 
        title: e.newsHeader, 
       )).toList()
      )
      ])
      )));
      }
      final List items = ['https://cdn.pixabay.com/photo/2015/02/15/09/33/news-636978_640.jpg'];
      }